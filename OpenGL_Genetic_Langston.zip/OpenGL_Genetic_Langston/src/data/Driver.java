package data;

import java.util.ArrayList;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

import Helpers.Artist;
import static Helpers.Artist.*;

public class Driver {
	
	private ArrayList<Tile> tiles = new ArrayList<>();
	final int TILE_SIZE = 10;
	final int WINDOW_LENGTH = 640;
	final int WINDOW_WIDTH = 640;
	final int OFFSET = 1;	//This is used to make the tiles and the ants look nicely dispersed.
	final int SPEED = 10;	//The amount of distance the ant goes each step. Basically the TILE_SIZE
	Ant ant;
	
	public Driver()
	{
		BeginSession();
		
		genTiles();
		genAnt(15,15);
				
		while (!Display.isCloseRequested())
		{
			
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		
		for (int i = 0; i < tiles.size(); i++)
		{
			tiles.get(i).update();
		}
		
		checkTile(ant);
		
		ant.update();
			
		Display.update();
		Display.sync(200);
		}
		
		Display.destroy();
 	}
	
	
	private void checkTile(Ant ant)
	{
		for (int i = 0; i < tiles.size(); i++)
		{
			if (tiles.get(i).getX() == ant.getX() && tiles.get(i).getY() == ant.getY())
			{
				if (tiles.get(i).isWhite())
				{
					ant.rotateClockwise();
				}
				else
				{
					ant.rotateCounterClockwise();
				}
				ant.move();
				tiles.get(i).changeColor();
				break;
			}
		}
	}
	
	private void genAnt(int x, int y)
	{
		int halfOfBoardLength = ((WINDOW_LENGTH/TILE_SIZE)/2) * TILE_SIZE;
		int halfOfBoardWidth = ((WINDOW_WIDTH/TILE_SIZE)/2) * TILE_SIZE;
		ant = new Ant(halfOfBoardLength+OFFSET,halfOfBoardWidth+OFFSET,TILE_SIZE,TILE_SIZE,Artist.quickLoad("ant"),"north", SPEED);
	}
	
	private void genTiles()
	{
		for (int x = 0; x < WINDOW_LENGTH/TILE_SIZE; x++)
		{
			for (int y= 0; y < WINDOW_WIDTH/TILE_SIZE; y++)
			{
				Tile t = new Tile(x*TILE_SIZE+OFFSET,y*TILE_SIZE+OFFSET,TILE_SIZE,TILE_SIZE,Artist.quickLoad("whiteTile"),true);
				tiles.add(t);
			}
		}
	}
	public static void main(String[] args)
	{
		new Driver();
	}
}