package data;

import org.newdawn.slick.opengl.Texture;

import Helpers.Artist;

public class Ant {
	
	private float x,y,height, width;
	private Texture tex;
	private String direction;
	private int speed;
	
	public Ant(float x, float y, float height, float width, Texture tex, String direction, int speed)
	{
		this.y = y;
		this.x = x;
		this.height = height;
		this.width = width;
		this.tex = tex;
		this.direction = direction;
		this.speed = speed;
	}
	
	private void draw()
	{
		Artist.DrawQuadTex(tex, x, y, height, width);
	}
	
	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}
	
	public void changeTexture(Texture newTexture)
	{
		tex = newTexture;
	}
	
	
	
	public void move()
	{
		if (direction.equals("north"))
		{
			moveUp();
		}
		else if (direction.equals("south"))
		{
			moveDown();
		}
		else if (direction.equals("west"))
		{
			moveLeft();
		}
		else if (direction.equals("east"))
		{
			moveRight();
		}
	}

	
	public void rotateClockwise()
	{
		if (direction.equals("north"))
		{
			changeTexture(Artist.quickLoad("ant"));	//east
			direction = "east";
		}
		else if (direction.equals("south"))
		{
			changeTexture(Artist.quickLoad("ant"));	//west
			direction = "west";
		}
		else if (direction.equals("west"))
		{
			changeTexture(Artist.quickLoad("ant"));	//north
			direction = "north";
		}
		else if (direction.equals("east"))
		{
			changeTexture(Artist.quickLoad("ant"));	//south
			direction = "south";
		}
	}
	
	
	
	
	public void rotateCounterClockwise()
	{
		if (direction.equals("north"))
		{
			changeTexture(Artist.quickLoad("ant"));	//west
			direction = "west";
		}
		else if (direction.equals("south"))
		{
			changeTexture(Artist.quickLoad("ant"));	//east
			direction = "east";
		}
		else if (direction.equals("west"))
		{
			changeTexture(Artist.quickLoad("ant"));	//south
			direction = "south";
		}
		else if (direction.equals("east"))
		{
			changeTexture(Artist.quickLoad("ant"));	//north
			direction = "north";
		}
	}
	
	public void moveRight()
	{
		x += speed;
	}
	public void moveLeft()
	{
		x -= speed;
	}
	public void moveUp()
	{
		y -= speed;
	}
	public void moveDown()
	{
		y += speed;
	}
	
	public void update()
	{
		draw();
	}
}