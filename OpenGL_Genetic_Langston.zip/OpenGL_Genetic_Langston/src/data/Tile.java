package data;

import org.newdawn.slick.opengl.Texture;

import Helpers.Artist;

public class Tile {
	
	private float x,y,height, width;
	private Texture tex;
	private boolean isWhite;
	
	public Tile(float x, float y, float height, float width, Texture tex, boolean isWhite)
	{
		this.y = y;
		this.x = x;
		this.height = height;
		this.width = width;
		this.tex = tex;
		this.isWhite = isWhite;
	}
	
	private void draw()
	{
		Artist.DrawQuadTex(tex, x, y, height, width);
	}
	
	public boolean isWhite()
	{
		return isWhite;
	}
	
	public void changeColor()
	{
		if (isWhite())
		{
			tex = Artist.quickLoad("blackTile");
			isWhite = false;
		}
		else
		{
			tex = Artist.quickLoad("whiteTile");
			isWhite = true;
		}
	}
	
	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public void update()
	{
		draw();
	}
}
